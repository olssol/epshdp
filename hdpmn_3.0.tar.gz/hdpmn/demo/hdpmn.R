###
### hdpmn.R - Demo
###

require(hdpmn)

## data files
data.dir <- system.file("data",package="hdpmn")

## data files
Z <- file.path(data.dir,"CALGBz.txt")  
     ## data (first 7 columns) and covariates (last 3 columns)
X <- file.path(data.dir,"CALGBz0.txt")
     ## same as Z, for future patients (for prediction)
S <- file.path(data.dir,"CALGBstudy.txt")
     ## table of patient number and study index
pa.st <- as.matrix(read.table(S,header=T))
study <- pa.st[,2]  # get study index


## run MCMC -- save working files in current working directory
hdpmn(Z=Z,nstudies=3,n.iter=1500,study=study,px=3,q=15,cc=15)

## post-process MCMC output for predictive inference
## save posterior predictive simulations in z00 ... z30
z10 <- hdpmnPredict(X=X,px=3,j=1,r=0) # post prediction for study 1
z20 <- hdpmnPredict(X=X,px=3,j=2,r=0) # .. study 2
z30 <- hdpmnPredict(X=X,px=3,j=3,r=0) # .. population at large (= study 3)

z11 <- hdpmnPredict(X=X,px=3,j=1,r=1) # idiosyncratic measures study 1
z21 <- hdpmnPredict(X=X,px=3,j=2,r=1) # .. study 2
z00 <- hdpmnPredict(X=X,px=3,j=0,r=0) # common measure

## covariates (and dummy random effects) of future patients
X <- as.matrix(read.table(X,header=T))
colnames(z00) <- c("PATIENT",colnames(X))

## plot estimated density for future patients in study 1, 2 and
## in population at large
idx <- which(z10[,1]==1)   ## PATIENT 1
options(digits=2)

## plot prediction fo study 1,2,population
plot  (density(z10[idx,8]),
       ylim=c(0,1.5),xlim=c(-0.5,2.5),
       xlab="SLOPE OF RECOVERY",bty="l",main="FUTURE PAT 1")
lines (density(z20[idx,8]),type="l",col=2)
lines (density(z30[idx,8]),type="l",col=3)
legend(1.0,1.5,col=1:3,legend=c("STUDY 1","STUDY 2","POPULATION"),
       lty=c(1,1,1),bty="n")

## common and idiosyncratic measures
plot (density(z00[idx,8]),type="l",col=4,lty=1,
       ylim=c(0,1.5),xlim=c(-0.5,2.5),
       xlab="SLOPE OF RECOVERY",bty="l",main="COMMON & IDIOSYNC PARTS")
lines (density(z11[idx,8]),type="l",col=1,lty=2)
lines (density(z21[idx,8]),type="l",col=2,lty=2)
legend(1.5,1.5,col=c(1,2,4),lty=c(2,2,1),
       legend=c("STUDY 1 (idiosyn.)",
                "STUDY 2 (idiosyn.)",
                "COMMON"),bty="n")

## plot estimated density for future patients in study 1, 2 and
## in population at large
idx <- which(z10[,1]==2)   ## PATIENT 2
options(digits=2)


plot  (density(z10[idx,8]),
       ylim=c(0,1.5),xlim=c(-0.5,2.5),
       xlab="SLOPE OF RECOVERY",bty="l",main="FUTURE PAT 2")
lines (density(z20[idx,8]),type="l",col=2)
lines (density(z30[idx,8]),type="l",col=3)
legend(-0.5,1.5,col=1:3,legend=c("STUDY 1","STUDY 2","POPULATION"),
       lty=c(1,1,1),bty="n")

plot (density(z00[idx,8]),type="l",col=4,lty=1,
       ylim=c(0,1.5),xlim=c(-0.5,2.5),
       xlab="SLOPE OF RECOVERY",bty="l",main="COMMON & IDIOSYNC PARTS")
lines (density(z11[idx,8]),type="l",col=1,lty=2)
lines (density(z21[idx,8]),type="l",col=2,lty=2)
legend(1.5,1.5,col=c(1,2,4),lty=c(2,2,1),
       legend=c("STUDY 1 (idiosyn.)",
                "STUDY 2 (idiosyn.)",
                "COMMON"),bty="n")

## plot nadir count by covariate, for population 
z2 <- z30[,3]; ctx <- z30[,9]; gm <- z30[,10]; amf <- z30[,11]
## fix covariates gm (GM-CSF) and amf (aminofostine)
idx <- which( (gm==-1.78) & (amf== -0.36) )
boxplot(split(z2,ctx),
        xlab="CYCLOPHOSPHAMIDE",bty="n",ylab="NADIR COUNT")



