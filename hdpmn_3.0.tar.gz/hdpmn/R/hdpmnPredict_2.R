##conditional normal distribution
get.cond.Normal <- function(mu, sigma, vec.y) {

    ##missing
    req.ind <- which(is.na(vec.y));

    if (length(mu) == length(req.ind)) {
        rst <- list(mu=mu, sigma=sigma);
    } else if (0 == length(req.ind)) {
        rst <- NULL;
    } else {
        given.ind <- which(!is.na(vec.y));
        B         <- sigma[req.ind, req.ind];
        C         <- sigma[req.ind, given.ind, drop=FALSE];
        D         <- sigma[given.ind, given.ind];
        CDinv     <- C %*% solve(D);
        cMu       <- c(mu[req.ind] + CDinv %*% (vec.y[given.ind] - mu[given.ind]));
        cVar      <- B - CDinv %*% t(C);

        if (is.matrix(cVar) & !isSymmetric(cVar)) {
            for (i in 1:(nrow(cVar)-1)) {
                for (j in (i+1):nrow(cVar)) {
                    cVar[i,j] <- cVar[j,i];
                }
            }
        }

        rst  <- list(mu=cMu, sigma=cVar);
    }

    ##return
    rst
}

R.hdpmnPredict <-  function(j=1,     # study index
                            r=0,     # indicator for including (0) or not (1) the common msr
                            nsim=100,   # max MCMC iterations to use
                            npa=NULL,   # number of future patients
                            idx.x=NULL,   # indcies of covariate vectors (start countint @1!)
                            X=NULL,     # (npa x px) matrix of covariates for future pat's
                            work.dir=NULL,   # directory to find the working files from hdpm
                            header=T,
                            out.f=paste("pred",j,r,sep="_")) {
    ## computes posterior predictive for future patients
    ## 1. read in covariates for desired posterior predictive
    if(is.null(X)){
        cat("\n *** Error: need X, covariates for future patients.")
        cat("\n     specify as file name or matrix.\n")
        return(-1)
    }

    if(!is.numeric(X)){
        dta <- read.table(X,header)
        X   <- as.matrix(dta)
    }

    ## 2. change working directory (if requested..)
    if(!is.null(work.dir)){
        cat("\n Changing working directory to ",work.dir,"\n")
        old.dir <- getwd()  # by default work in current working directory
        setwd(work.dir)
    }

    ## 3. check paramters
    if(is.null(npa))
        npa <- nrow(X)
    if(npa != nrow(X)){
        cat("\n *** Error: need npa=nrow(X).\n")
        return(-1)
    }

    if (is.null(idx.x)){
        cat("\n *** Warning: did not specify the indices of the covariates.\n",
            "    assuming the last ",px," coordinates are covariates.\n")
        idx.x <- 2:ncol(X);
    }

    if (j != abs(round(j))){ # not an integer
        cat("\n *** Error: j needs to 0 or a study index 1..(J+1),\n",
            "     where J = number of studies.\n")
        return(-1)
    }

    if (!is.element(r,0:1)){
        cat("\n *** Error: r=0 or 1 required.\n")
        return(-1)
    }

    cat("\n Computing predictive for (j,r)=(",c(j,r),
        ") i.e., study ",j)
    if(r==0)        cat(" with ")
    else            cat(" without ")
    cat(" common measure.\n")

    ## out <- file("init.p",open="w")
    ## cat(" n ",nsim,"\n",
    ##     " p ",p,"\n",
    ##     "npa ", npa, "\n",
    ##     "px ", px,"\n",
    ##     "idx_c", idx.x-1,"\n",  # NOTE: -1 for C indexing strting at 0
    ##     "data-z \n",
    ##     rbind(format(t(X)),"\n"),
    ##     file=out)
    ## close(out)
    ##.C("predictN",
    ##   jpredp=as.integer(j),
    ##   rpredp=as.integer(r),
    ##   package="hdpmn");

    ##fn   <- paste("z-",j,r,".p",sep="") # output file
    ##zout <- read.table(file=fn);

    ##----predict--------
    mj.mdp   <- read.table(file="mj.mdp");
    vj.mdp   <- read.table(file="Vt.mdp");
    lst.iter <- unique(mj.mdp[,1]);
    zout     <- NULL;
    for (i in 1:npa) {
        print(i);
        cur.x <- X[i, ,drop=FALSE];
        for (k in lst.iter) {
            ##print(k);
            cur.inx  <- which(k == mj.mdp[,1]);
            cur.mj   <- mj.mdp[cur.inx,];
            cur.vj   <- vj.mdp[cur.inx,];
            cur.pred <- pred.single(j, r, cur.x, cur.mj, cur.vj, idx.x, nsim);
            zout     <- rbind(zout, cbind(i, k, cur.pred));
        }

        if (nrow(zout > 10000)) {
            write.table(zout, file=out.f, append=(i>1), row.names=FALSE, col.names=FALSE);
            zout <- NULL;
        }
    }

    ## change working directory back (if changed earlier..)
    if(!is.null(work.dir)){
        cat("\n Changing working directory back to ",old.dir,"\n")
        setwd(old.dir)
    }

    return(zout)
}

##predict outcome for a single patient at a single iteration
pred.single <- function(j, r, x, mj, vj, idx.x, nsim=0) {

    if (0 == nsim) {
        lrtn = 1;
    } else {
        lrtn = nsim;
    }

    rst <- .C("predict_single",
              as.integer(j),
              as.integer(r),
              as.double(x),
              as.integer(idx.x-1),
              as.integer(length(idx.x)),
              as.double(t(as.matrix(mj))),
              as.double(t(as.matrix(vj))),
              as.integer(nrow(mj)),
              as.integer(ncol(mj)-3),
              as.integer(nsim),
              result=double(lrtn));

    ##return
    rst[['result']];
}

##predict outcome for a single patient at a single iteration
R.pred.single <- function(j, r, x, mj, vj, idx.x, nsim=0) {

    nmj <- nrow(mj);
    p   <- ncol(mj)-3;

    ##get standardized weights
    weights <- rep(0, nmj);
    for (i in 1:nmj) {
        cur.j <- mj[i,2];
        cur.w <- mj[i,3];

        ##ignore current row, weight=0
        if (cur.j > 0 & cur.j != j)
            next;
        if (cur.j == 0 & j != 0 & r !=0)
            next;
        if (0 == cur.w)
            next;

        ##weight x
        cur.x.mu   <- as.matrix(mj[i, 3+idx.x]);
        cur.vj     <- matrix(unlist(vj[i, -(1:3)]), nrow=p, ncol=p);
        cur.x.v    <- as.matrix(cur.vj[idx.x, idx.x]);
        x.weight   <- mvtnorm::dmvnorm(x, cur.x.mu, sigma=cur.x.v);
        weights[i] <- cur.w * x.weight;
    }
    weights <- weights/sum(weights);

    ##generate random draws
    if (nsim > 0)
        draw.cluster <- rmultinom(1, nsim, weights);

    ##draw predicts
    rst <- NULL;
    for (i in 1:nmj) {
        if (nsim > 0) {
            cur.n <- draw.cluster[i];
            if (0 == cur.n)
                next;
        } else if (0 == weights[i]) {
            rst <- c(rst, 0);
            next;
        }

        ##conditional mean and variance
        cur.mu   <- as.matrix(mj[i, 3+c(1,idx.x)]);
        cur.vj   <- matrix(unlist(vj[i, -(1:3)]), nrow=p, ncol=p);
        cur.v    <- as.matrix(cur.vj[c(1, idx.x), c(1, idx.x)]);
        cur.cond <- get.cond.Normal(cur.mu, cur.v, c(NA, x));

        if (nsim > 0) {
            cur.pred <- rnorm(cur.n, cur.cond$mu, sd=sqrt(cur.cond$sigma));
        } else {
            cur.pred <- cur.cond$mu;
        }
        rst <- c(rst, cur.pred);
    }
    ##weighted mean if nsim = 0
    if (nsim <= 0)
        rst <- sum(weights * rst);

    ##return
    rst
}
