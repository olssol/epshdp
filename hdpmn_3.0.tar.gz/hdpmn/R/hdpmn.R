`hdpmn` <- function(
    Z=NULL,         # initial r.e. and covariates (matrix or fn)
    study=NULL,     # indicators for study of i-th patient
    npatients=NULL, # sample size (n patients)
    nstudies=NULL,  # number of submodels (studies)
    n.iter=1000,    # n MCMC iterations
    n.discard=100,  # initial transient
    n.batch=50,     # batch size to thin out
    y.type=c("continuous", "binary", "survival"), # types of response
    verbose=3,      # 0=no commens
    seed1=981963,   # r.v. seeds
    seed2=6869504,
    mcmc.eps=0,     # indicator for sampling epsilon
    eps=0.1,        # prob idiosyncratic cluster
    ae=1,           # p(eps) ~ pe0*I(0)+pe1*I(1)+
    ## (1-pe0-pe1)*Be(ae,be)
    be=1,
    pe1=0.1,        #
    pe0=0.1,
    ## pars for DP mixture r.e. prior
    pz=NULL,        # dimension of random eff (incl cov's)
    px=NULL,        # dim of covariate vector
    m.prior=0,      # resample m
    B.prior=0,      # resample B
    S.prior=0,      # resample S
    alpha.prior=0,  # resample alpha
    n.predupdate=n.batch,
    S.init=NULL,    # initial value and prior mean for S
    q=10,           # d.f. for prior on S, 1/S ~ W(q,1/(qR)]
    R=NULL,         # hyperprior mean for S
    B.init=NULL,    # initial value for B in G0(mu)=N(m,B)
    cc=10,           # d.f. par c for prior 1/B ~ W(c,1/(cC))
    C=NULL,         # hyperprior par C
    m.init=NULL,    # initial values for m
    a=NULL,         # hyperpar a for prior m ~ N(a,A)
    A=NULL,         # hyperpar A

    alpha=1,        # initial value for total mass alpha
    a0=1,
    b0=1,           # hyperprior pars for alpha ~ IG(a0/2,b0/2)
    k0=NULL,        # initial number of clusters
    work.dir=NULL,  # directory to work in
    header=T)       # indicator for headers in Y and Z files

{
    options(digits=10)

    ## 1. read in data file and covariates (need pz for 'init.giis')
    if(is.null(Z)){
        cat("\n *** Error: must specify ",
            " initial random effects Z (matrix or filename).\n")
        return(-1)
    }

    if(!is.numeric(Z)){
        dta <- read.table(Z,header=header)
        if (is.null(dta)){ ## reading in data did not work
            cat("\n *** Error: could not read data from file",Z,
                "\n Hint: need to include full path.\n")
            return(-1)
        }
        if (verbose>0){
            cat("Read ", nrow(dta), " rows and ", ncol(dta), " columns",
                "from data file ", Z,"\n")
            if (header)
                cat("First line is interpreted as variable names.\n")
        }
        Z <- as.matrix(dta)
    }

    ## change working directory (if requested..)
    if(!is.null(work.dir)){
        cat("\n Changing working directory to ",work.dir,"\n")
        old.dir <- getwd()  # by default work in current working directory
        setwd(work.dir)
    }

    ## set default parameters
    if(is.null(study)){
        cat("\n *** Error: need list of study indicators 'study'.\n")
        return(-1)
    }
    if (sum(abs(study-round(study)))>0){ # not integers
        cat("\n *** Error: study indicators need to be integers 1...nstudies.\n")
        return(-1)
    }
    if (length(unique(study)) != max(study)){
        cat("\n *** Error: studies need to be indexed 1...nstudies.\n")
        return(-1)
    }
    if (is.null(nstudies))
        nstudies <- max(study)
    if (nstudies != max(study)){
        cat("\n *** Error: nstudies does not match study indicators.\n")
        ##cat(" Should be max(study) + 1 (for future study).\n")
        return(-1)
    }
    if (is.null(npatients))
        npatients <- nrow(Z)
    else
        if (npatients != nrow(Z)){
            cat("\n *** Error: npatients does not match nrow(Z).\n")
            return(-1)
        }
    if (n.discard >= n.iter){
        cat("\n *** Error: n.iter <= n.discard. \n")
        return(-1)
    }
    if (n.batch >= n.iter/2){
        cat("\n *** Error: n.iter/2 <= n.batch. \n")
        return(-1)
    }
    if (pe1+pe0 >= 1.0){
        cat("\n *** Error: need pe0+pe1 < 1.\n")
        return(-1)
    }
    if (!is.element(mcmc.eps,c(0,1))){
        cat("\n *** Error: mcmc.eps not in {0,1}.\n")
        return(-1)
    }
    if ((eps<0) | (eps>1)){
        cat("\n *** Error: eps not in [0,1].\n")
        return(-1)
    }
    if(is.null(pz))
        pz <- ncol(Z)
    if(pz != ncol(Z)){
        cat("\n *** Error: ncol(Z) != pz. Need to match.\n")
        return(-1)
    }

    ##type of response outcome
    y.type     <- match.arg(y.type);
    y.type.inx <- which(y.type == c("continuous", "binary", "survival"));

    out <- file("init.giis",open="w")
    cat("data-npatients ",npatients,"\n",
        "data-nstudies ", nstudies, "\n",
        "model-p1 ", pz, "\n",
        "data-study ", format(study), "\n",
        "data-type ", as.integer(y.type.inx), "\n", ##type of response
        "mcmc-niter", n.iter, "\n",
        "mcmc-npi ", n.batch, "\n",
        "mcmc-nbatch 5 \n",
        "mcmc-ndiscard ",n.discard, "\n",
        "mcmc-verbose ", verbose, "\n",
        "mcmc-seed1 ", seed1, "\n",
        "mcmc-seed2 ", seed2, "\n",
        "mcmc-eps ", mcmc.eps, "\n",
        "model-eps ", eps, "\n",
        "model-ae ", ae,   "\n",
        "model-be ", be,   "\n",
        "model-pe0 ", pe0, "\n",
        "model-pe1 ", pe1, "\n",
        file=out);
    close(out);

    ## initialization file init.mdp for MDP model
    if (is.null(px)){
        cat("\n **** Error: need px=dim(covariate vector).")
        cat("\n      Note:  px < pz = ncol(Z).")
        cat("\n      Use px=0 for no covariates.\n")
        return(-1)
    }

    if (px >= pz){
        cat("\n Error: dim(covariates) >= dim(response AND covariates), ",
            "i.e., px>=pz. Can't be.\n")
        return(-1)
    }
    ## moments of initial r.e. for initializations..
    mhat <- apply(Z,2,mean)
    V <- var(Z)
    v <- diag(V)

    if (!is.null(S.init))
        if ( (nrow(S.init) != pz) | (ncol(S.init) != pz)){
            cat("\n *** Error: dim(S.init) != (pz x pz).\n")
            cat(" Note: S includes the covariates!.\n")
            return(-1)
        }
    if (!is.null(B.init))
        if ( (nrow(B.init) != pz) | (ncol(B.init) != pz)){
            cat("\n *** Error: dim(B.init) != (pz x pz).\n")
            cat(" Note: B includes the covariates!.\n")
            return(-1)
        }
    if (!is.null(C))
        if ( (nrow(C) != pz) | (ncol(C) != pz)){
            cat("\n *** Error: dim(C) != (p x p).\n")
            cat(" Note: dim(C) includes the covariates!.\n")
            return(-1)
        }
    if (!is.null(A))
        if ( (nrow(A) != pz) | (ncol(A) != pz)){
            cat("\n *** Error: dim(A) != (p x p).\n")
            cat(" Note: dim(A) includes the covariates!.\n")
            return(-1)
        }
    if (!is.null(m.init))
        if (length(m.init) != pz){
            cat("\n *** Error: length(m) != p.\n")
            cat(" Note: dim(m) includes the covariates!.\n")
            return(-1)
        }
    if (!is.null(a))
        if (length(a) != pz){
            cat("\n *** Error: length(a) != p.\n")
            cat(" Note: dim(a) includes the covariates!.\n")
            return(-1)
        }

    ## 2. default parameters
    if(is.null(S.init)){
        S.init <- 0.25*V
        cat(" setting default for S.init = 1/4*var(Z).\n")
    }
    if(is.null(R)){
        R <- 0.25*diag(v)
        cat(" setting default for R = 1/4*diag(var(Z)).\n")
    }
    if(is.null(B.init)){
        B.init <- diag(v)
        cat(" setting default for B.init = var(var(Z)).\n")
    }
    if(is.null(m.init)){
        m.init <- mhat
        cat(" setting default for m.init = column mean(Z).\n")
    }
    if(is.null(C)){
        C <- diag(v)
        cat(" setting default for C = diag(var(Z)).\n")
    }
    if(is.null(A)){
        A <- diag(v)
        cat(" setting default for A = diag(diag(Z)).\n")
    }
    if(is.null(a)){
        a <- mhat
        cat(" setting default for a = column mean(Z).\n")
    }
    if(is.null(k0)){
        k0 <- npatients
        cat(" setting default for k0=npatients.\n")
    }
    if ( (k0 != 1) & (k0 != npatients)){
        cat("\n *** Error: k0 not in {1,n}.\n")
        return(-1)
    }
    if (!is.element(m.prior,c(0,1))){
        cat("\n *** Error: m.prior = 0 or 1 required.\n")
        return(-1)
    }
    if (!is.element(B.prior,c(0,1))){
        cat("\n *** Error: B.prior = 0 or 1 required.\n")
        return(-1)
    }
    if (!is.element(alpha.prior,c(0,1))){
        cat("\n *** Error: alpha.prior = 0 or 1 required.\n")
        return(-1)
    }

    ## warnings
    if (cc < pz+2)
        cat(" *** Warning: should use c > p+2 for good mixing MCMC.\n")
    if (q < pz+2)
        cat(" *** Warning: should use q > p+2 for good mixing MCMC.\n")

    ## 3. write init file
    out <- file("init.mdp",open="w")
    cat(" data-p ",pz,
        "\n model-m_prior ", m.prior,
        "\n model-B_prior ", B.prior,
        "\n model-S_prior ", S.prior,
        "\n model-alpha_prior ", alpha.prior,
        "\n mcmc-npredupdate ", n.predupdate,
        "\n par-S \n", rbind( format(S.init),"\n"),
        "\n par-q ", q,
        "\n par-R  \n", rbind( format(R),"\n"),
        "\n par-B \n", rbind(format(B.init),"\n"),
        "\n par-c ", cc,
        "\n par-C \n ", rbind(format(C),"\n"),
        "\n par-m ", format(m.init),
        "\n par-aa ", format(a),
        "\n par-Ainv \n", rbind( format(solve(A)),"\n"),
        "\n par-alpha ", alpha,
        "\n par-aalpha ", a0,
        "\n par-balpha ", b0,
        "\n init-k0 ", k0, "\n",
        file=out)
    close(out)

    ## 4. write data file
    out <- file("data-z.giis",open="w")
    cat("data-z \n",file=out)
    write(format(t(Z)),ncolumns=pz,file=out)
    close(out)

    ## 5. call C executable
    if (verbose>0)
        cat(" Printing trace of form:   iteration:k=k0+k1+k2..+kJ\n",
            " where k  = total # clusters and k0 = # clusters in common measure,",
            "       kj = # clusters in idiosyncratic measure j.\n\n")
                .C("hdpmn", package="hdpmn")
    if (verbose>1){
        cat(" Results are saved in files '*.mdp' and '*.giis'. \n")
        cat(" in the working directory \n")
    }

    ## 6. return error code
    if(!is.null(work.dir)){
        cat("\n Changing working directory back to ",old.dir,"\n")
        setwd(old.dir)
    }
}

