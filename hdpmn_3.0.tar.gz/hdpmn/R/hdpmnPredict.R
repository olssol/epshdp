`hdpmnPredict` <-
function(j=1,     # study index
           r=0,     # indicator for including (0) or not (1) the common msr
           nsim=100,   # max MCMC iterations to use
           p=NULL,  # dimension of data records (including covariates)
           npa=NULL,   # number of future patients
           px=NULL,    # size of covariate vector
           idx.x=NULL,   # indcies of covariate vectors (start countint @1!)
           X=NULL,     # (npa x px) matrix of covariates for future pat's
           work.dir=NULL,   # directory to find the working files from hdpm
           header=T)
{# computes posterior predictive for future patients

  ## 1. read in covariates for desired posterior predictive
  if(is.null(X)){
    cat("\n *** Error: need X, covariates for future patients.")
    cat("\n     specify as file name or matrix.\n")
    return(-1)
  }
  if(!is.numeric(X)){
    dta <- read.table(X,header)
    X <- as.matrix(dta)
  }

  ## 2. change working directory (if requested..)
  if(!is.null(work.dir)){
    cat("\n Changing working directory to ",work.dir,"\n")
    old.dir <- getwd()  # by default work in current working directory
    setwd(work.dir)
  }

  ## 3. check paramters
  if (!is.null(p)){
    if (p != ncol(X)){
      cat("\n *** Error: need p=ncol(X).")
      cat("   Note: X should include dummy random effects (use 0, e.g.).\n")
      return(-1)
    }
  } else {
    p <- ncol(X)
  }
  if(is.null(npa))
    npa <- nrow(X)
  if(npa != nrow(X)){
    cat("\n *** Error: need npa=nrow(X).\n")
    return(-1)
  }
  if (is.null(px)){
    cat("\n *** Error: need px, dimension of covariate vector",
        "(W/O random effects")
    cat("\n     specify px.\n")
    return(-1)
  }
  if (is.null(idx.x)){
    cat("\n *** Warning: did not specify the indices of the covariates.\n",
           "    assuming the last ",px," coordinates are covariates.\n")
    idx.x <- (p-px+1):p
  }
  if (j != abs(round(j))){ # not an integer
    cat("\n *** Error: j needs to 0 or a study index 1..(J+1),\n",
          "     where J = number of studies.\n")
    return(-1)
  }
  if (!is.element(r,0:1)){
    cat("\n *** Error: r=0 or 1 required.\n")
    return(-1)
  }
  
  out <- file("init.p",open="w")
  cat(" n ",nsim,"\n",
      " p ",p,"\n",
      "npa ", npa, "\n",
      "px ", px,"\n",
      "idx_c", idx.x-1,"\n",  # NOTE: -1 for C indexing strting at 0
      "data-z \n",
      rbind(format(t(X)),"\n"),
      file=out)
  close(out)

  cat("\n Computing predictive for (j,r)=(",c(j,r),
          ") i.e., study ",j)
  if(r==0)        cat(" with ")
  else            cat(" without ")
  cat(" common measure.\n")
  .C("predictN",
     jpredp=as.integer(j),
     rpredp=as.integer(r),
     package="hdpmn")

  fn <- paste("z-",j,r,".p",sep="") # output file
  zout <- as.matrix(read.table(fn))

  ## change working directory back (if changed earlier..)
  if(!is.null(work.dir)){
    cat("\n Changing working directory back to ",old.dir,"\n")
    setwd(old.dir)
  }
  return(zout)
}

