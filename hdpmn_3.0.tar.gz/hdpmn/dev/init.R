source("/Users/pm/s/first.s")
setwd("/Users/pm/smooth/R/hdpmn/dev")
Y <- as.matrix(read.table("CALGB.txt",header=T))

pa <- Y[,1]
st <- Y[,ncol(Y)]
patlist <- unique(pa)
npa <- length(patlist)
study <- rep(0,npa)
for(i in 1:nrow(Y)){
  pa1 <- pa[i]+1 # starts indexing with 1!
  if (study[pa1]==0)
    study[pa1] <- st[i]
}
