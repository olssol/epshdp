double ran1(int *);
double gasdev(int *);
